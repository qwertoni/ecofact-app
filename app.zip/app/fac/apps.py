from django.apps import AppConfig


class FacConfig(AppConfig):
    name = 'fac'
