from django.apps import AppConfig


class CmpConfig(AppConfig):
    name = 'cmp'
